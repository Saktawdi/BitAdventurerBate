"use strict";
cc._RF.push(module, '6af18vuSfdIHqBz6J+Emx6C', 'dashBtn');
// script/UiBtn/dashBtn.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.dashSPD = 0; //冲刺移动的幅度
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    NewClass.prototype.onLoad = function () {
        this.hero = cc.find("Canvas/hero");
        this.heroScript = this.hero.getComponent('hero');
        this.circularBar = cc.find('Canvas/bg/UiCamera/UI/dashBtn/btnDash/circularBar').getComponent(cc.Sprite);
        this.mapname = cc.director.getScene().name;
    };
    NewClass.prototype.start = function () {
        this.node.on(cc.Node.EventType.TOUCH_START, function () {
            var _this = this;
            this.node.scaleX = 1;
            this.node.scaleY = 1;
            if (this.heroScript.dashif == false && this.heroScript.state != 'die') {
                this.heroScript.Aniplay('dash');
                this.dashSPD = 800;
                this.heroScript.dashif = true;
                this.circularBar.fillRange = 0;
                this.DashLogin();
                setTimeout(function () {
                    _this.dashSPD = 0;
                }, 600);
                this.schedule(this.changeProgressBar, 0.1);
                setTimeout(function () {
                    _this.heroScript.dashif = false;
                }, 2000);
            }
        }, this);
        this.node.on(cc.Node.EventType.TOUCH_END, function () {
            this.node.scaleX = 0.8;
            this.node.scaleY = 0.8;
        }, this);
    };
    NewClass.prototype.DashLogin = function () {
        var _this = this;
        setTimeout(function () {
            var dash = cc.instantiate(_this.dasheff);
            dash.parent = _this.hero.parent;
            dash.x = _this.hero.x;
            dash.y = _this.hero.y + 15;
        }, 60);
        setTimeout(function () {
            var dash = cc.instantiate(_this.dasheff);
            dash.parent = _this.hero.parent;
            dash.x = _this.hero.x;
            dash.y = _this.hero.y + 15;
        }, 120);
        setTimeout(function () {
            var dash = cc.instantiate(_this.dasheff);
            dash.parent = _this.hero.parent;
            dash.x = _this.hero.x;
            dash.y = _this.hero.y + 15;
        }, 180);
        setTimeout(function () {
            var dash = cc.instantiate(_this.dasheff);
            dash.parent = _this.hero.parent;
            dash.x = _this.hero.x;
            dash.y = _this.hero.y + 15;
        }, 240);
        setTimeout(function () {
            var dash = cc.instantiate(_this.dasheff);
            dash.parent = _this.hero.parent;
            dash.x = _this.hero.x;
            dash.y = _this.hero.y + 15;
        }, 300);
    };
    NewClass.prototype.changeProgressBar = function () {
        this.circularBar.fillRange += 0.05;
        if (this.circularBar.fillRange >= 1) {
            this.unschedule(this.changeProgressBar);
        }
    };
    NewClass.prototype.update = function (dt) {
        if (this.mapname == 'map000') {
            if (this.hero.x >= -224 && this.hero.x <= 740) {
                this.hero.x += this.dashSPD * dt * this.hero.scaleX;
            }
        }
        else if (this.mapname == 'map001') {
            if (this.hero.x >= -224 && this.hero.x <= 1840) {
                this.hero.x += this.dashSPD * dt * this.hero.scaleX;
            }
        }
        else if (this.mapname == 'restartvillage') {
            if (this.hero.x >= -167 && this.hero.x <= 1760) {
                this.hero.x += this.dashSPD * dt * this.hero.scaleX;
            }
        }
        if (this.dashSPD >= 30) {
            this.dashSPD -= 30;
        }
        if (this.dashSPD < 0) {
            this.dashSPD = 0;
        }
    };
    __decorate([
        property(cc.Prefab)
    ], NewClass.prototype, "dasheff", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();