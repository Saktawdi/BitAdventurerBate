"use strict";
cc._RF.push(module, '71d64Peic1B/YPVYgF6l6D1', 'enemy');
// script/enemy.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.hurteff = null;
        _this.HpBar = null;
        _this.sight = 100;
        _this.FightRange = 50;
        _this.ifRemoteEnemy = false;
        _this.flyingif = false; //远程飞行道具
        _this.chaseOff = true;
        _this.Orderstate = 'L'; //巡逻起始方向,LR左右，其他均停止
        _this.state = 'idle';
        _this.range = 0; //巡逻范围
        _this.speed = 60;
        _this.MaxHp = 100;
        _this.hp = 100;
        _this.combo = '';
        _this.enemyAni = null;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    NewClass.prototype.onLoad = function () {
        this.enemyAni = this.node.getChildByName('body').getComponent(cc.Animation);
        this.enemyAni.on('finished', this.onAnimaFinished, this);
        this.gameLoad = cc.find('Canvas/bg');
        if (this.gameLoad.getComponent('game') != null) {
            this.gameLoad.getComponent('game').enemyNumber++;
        }
        this.heroPos = cc.find('Canvas/hero');
        this.startPos = this.node.x;
        this.l = this.startPos - this.range;
        this.r = this.startPos + this.range;
        this.HpBar.node.opacity = 0;
        this.Aniplay('idle');
        this.hp = this.MaxHp;
        if (this.combo != '') {
            this.maxcombo = Number(this.combo);
            this.combo = '1';
        }
    };
    NewClass.prototype.Aniplay = function (state) {
        if (state == this.state)
            return;
        this.enemyAni.play(state);
        this.state = state;
    };
    NewClass.prototype.onAnimaFinished = function () {
        var comboNumber = Number(this.combo);
        if ((this.state == 'attack' + this.combo) && this.chaseOff == false) {
            this.state = 'attack666';
            this.chaseOff = true;
            switch (comboNumber) {
                case 1:
                    comboNumber++;
                    break;
                case 2:
                    comboNumber = 1;
                    break;
            }
            if (this.combo != '') {
                this.combo = String(comboNumber);
            }
        }
        if (this.state == 'die') {
            this.gameLoad.getComponent('game').enemyNumber--;
            this.node.destroy();
        }
    };
    NewClass.prototype.hurt = function (hurtValue) {
        if (hurtValue === void 0) { hurtValue = 20 * Math.random(); }
        var Hurteff = cc.instantiate(this.hurteff);
        Hurteff.parent = this.node.parent;
        Hurteff.setPosition(this.node.x, this.node.y + 18);
        this.hp -= hurtValue;
        this.HpBar.node.opacity = 255;
        if (this.hp >= 0) {
            this.HpBar.progress = this.hp / this.MaxHp;
        }
        else if (this.hp < 0) {
            this.HpBar.progress = 0;
        }
        if (this.hp <= 0) {
            this.Orderstate = 'D';
        }
        if (this.Orderstate != 'D') {
            this.Orderstate = 'H';
            this.enemyAni.play('hurt');
        }
    };
    NewClass.prototype.AutoFight = function () {
        var distance = this.node.x - this.heroPos.x;
        var heroScript = this.heroPos.getComponent('hero');
        if (Math.abs(distance) <= this.sight && (Math.abs(distance) > this.FightRange)) {
            //追击
            if (this.chaseOff == true) {
                this.Orderstate = 'Z';
                this.speed = heroScript.speed + 10;
                if (distance > 0) {
                    this.Orderstate = 'L';
                    this.node.scaleX = -1;
                    return -1 * this.speed;
                }
                if (distance < 0) {
                    this.Orderstate = 'R';
                    this.node.scaleX = 1;
                    return 1 * this.speed;
                }
            }
        }
        // if(Math.abs(distance)<=15){
        //     if(this.node.x<=550 && this.node.x>=300){
        //         this.speed=heroScript.speed+30
        //         if(distance<0){
        //             this.Orderstate='L'
        //             this.node.scaleX=-1
        //             return  -1*this.speed
        //         }
        //         if(distance>0){
        //             this.Orderstate='R'
        //             this.node.scaleX=1
        //             return  1*this.speed
        //         }
        //     }
        // }
        if (Math.abs(distance) <= this.FightRange) {
            //攻击
            this.Orderstate = 'F';
            this.chaseOff = false;
        }
    };
    NewClass.prototype.update = function (dt) {
        var Nowstate = '';
        this.lv = this.node.getComponent(cc.RigidBody).linearVelocity;
        if (this.Orderstate != 'D') {
            this.AutoFight();
        }
        switch (this.Orderstate) {
            case 'Z':
                this.lv.x = this.AutoFight();
                Nowstate = 'run';
                break;
            case 'L':
                this.lv.x = -1 * this.speed;
                this.node.scaleX = -1;
                Nowstate = 'run';
                if (this.node.x <= this.l) {
                    this.Orderstate = 'R';
                }
                break;
            case 'R':
                this.lv.x = 1 * this.speed;
                this.node.scaleX = 1;
                if (this.node.x >= this.r) {
                    this.Orderstate = 'L';
                }
                Nowstate = 'run';
                break;
            case 'H':
                this.lv.x = 0;
                Nowstate = 'hurt';
            case 'F':
                this.lv.x = 0;
                Nowstate = 'attack' + this.combo;
                break;
            case 'D':
                this.lv.x = 0;
                Nowstate = 'die';
            default:
                break;
        }
        this.Aniplay(Nowstate);
        this.node.getComponent(cc.RigidBody).linearVelocity = this.lv;
    };
    __decorate([
        property(cc.Prefab)
    ], NewClass.prototype, "hurteff", void 0);
    __decorate([
        property(cc.ProgressBar)
    ], NewClass.prototype, "HpBar", void 0);
    __decorate([
        property
    ], NewClass.prototype, "sight", void 0);
    __decorate([
        property
    ], NewClass.prototype, "FightRange", void 0);
    __decorate([
        property
    ], NewClass.prototype, "ifRemoteEnemy", void 0);
    __decorate([
        property(Boolean)
    ], NewClass.prototype, "chaseOff", void 0);
    __decorate([
        property
    ], NewClass.prototype, "Orderstate", void 0);
    __decorate([
        property
    ], NewClass.prototype, "range", void 0);
    __decorate([
        property
    ], NewClass.prototype, "speed", void 0);
    __decorate([
        property
    ], NewClass.prototype, "MaxHp", void 0);
    __decorate([
        property
    ], NewClass.prototype, "combo", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();